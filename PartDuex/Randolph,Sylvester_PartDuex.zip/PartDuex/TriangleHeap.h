#pragma once


class TriangleHeap
{

	private:

		float* base, * height;

	public:

		TriangleHeap(float* b, float* h);
		
		float getArea(float* b, float* h);
		



};

