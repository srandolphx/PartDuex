#pragma once
class TriangleStack
{

	
	private:

		float base, height;

	public:

		TriangleStack(float b, float h);
		
		float getArea(float b, float h);
		

};

